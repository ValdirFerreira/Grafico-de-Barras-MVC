﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebGrafico.Models
{
    public class GraficoModel
    {
        public string TituloRodape { get; set; }
        public int Porcentagem { get; set; }
    }
}
